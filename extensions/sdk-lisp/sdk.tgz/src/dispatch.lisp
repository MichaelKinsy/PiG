;;;; SPDX-License-Identifier: MIT
;;;; The connection loop: registration, the reader thread, one thread per request.

(in-package #:pig)

;;; ---------------------------------------------------------------- latches (request start order)

(defstruct (latch (:constructor make-latch ()))
  (lock (sb-thread:make-mutex :name "pig latch"))
  (queue (sb-thread:make-waitqueue))
  (flag nil))

(defun latch-set (latch)
  (sb-thread:with-mutex ((latch-lock latch))
    (setf (latch-flag latch) t)
    (sb-thread:condition-broadcast (latch-queue latch))))

(defun latch-wait (latch)
  (sb-thread:with-mutex ((latch-lock latch))
    (loop until (latch-flag latch) do (sb-thread:condition-wait (latch-queue latch) (latch-lock latch)))))

(defstruct (start-ticket (:constructor make-start-ticket (previous))) previous (done (make-latch)))

(defun ticket-begin (ticket)
  (when ticket
    (when (start-ticket-previous ticket) (latch-wait (start-ticket-previous ticket)))
    (latch-set (start-ticket-done ticket))))

(defvar *ticket-tails* (make-hash-table :test 'eq :synchronized t))

(defun reserve-ticket (ext)
  "The next place in the order handlers start. Only the reader thread calls it, in arrival order."
  (let ((ticket (make-start-ticket (gethash ext *ticket-tails*))))
    (setf (gethash ext *ticket-tails*) (start-ticket-done ticket))
    ticket))

(defun starts-in-arrival-order-p (method)
  (member method '("tool_call" "event" "command") :test #'equal))

;;; ---------------------------------------------------------------- registration payload

(defun register-payload (ext)
  (flet ((vec (list) (coerce list 'simple-vector)))
    (let ((payload (obj "name" (extension-name ext)
                        "tools" (vec (extension-tools ext))
                        "commands" (vec (extension-commands ext))
                        "shortcuts" (vec (extension-shortcuts ext))
                        "handlers" (vec (extension-handlers ext))
                        "flags" (vec (extension-flags ext)))))
      (dolist (entry *register-contributors*) (funcall (cdr entry) ext payload))
      payload)))

;;; ---------------------------------------------------------------- state from the host

(defun apply-ui-state (ext state)
  "Record the replicated values of a ready or state_update snapshot. The caller holds the state lock."
  (when (hash-table-p state)
    (let ((has-ui (jget state "hasUI")))
      (when (member has-ui '(t :false)) (setf (extension-has-ui ext) (eq has-ui t))))))

(defun apply-footer-data (ext data)
  "Install footer data; (values changed branch-changed). The caller holds the state lock."
  (when (hash-table-p data)
    (let* ((previous (extension-footer ext))
           (branch (let ((b (jget data "gitBranch"))) (and (stringp b) (plusp (length b)) b)))
           (statuses (make-hash-table :test 'equal))
           (raw (jget data "extensionStatuses"))
           (count (let ((c (jget data "availableProviderCount"))) (if (integerp c) c 0))))
      (when (hash-table-p raw) (maphash (lambda (k v) (setf (gethash k statuses) v)) raw))
      (let ((new (make-footer-data :branch branch :statuses statuses :count count)))
        (setf (extension-footer ext) new)
        (values (not (and (equal branch (footer-data-branch previous))
                          (= count (footer-data-count previous))
                          (equalp (to-json (footer-data-statuses new)) (to-json (footer-data-statuses previous)))))
                (not (equal branch (footer-data-branch previous))))))))

(defun apply-run-signal (ext frame)
  (let (signal)
    (sb-thread:with-mutex ((extension-state-lock ext))
      (cond ((not (eq (jget frame "active") t)) (setf (extension-run-signal ext) nil))
            (t (let ((run (let ((r (jget frame "run"))) (if (integerp r) r 0))))
                 (unless (and (extension-run-signal ext) (eql (car (extension-run-signal ext)) run))
                   (setf (extension-run-signal ext) (cons run (make-abort-signal))))
                 (setf signal (cdr (extension-run-signal ext)))))))
    (when (and signal (eq (jget frame "aborted") t)) (signal-abort signal))))

(defun handle-notify (ext env)
  (let* ((notify (or (jget env "notify") (obj)))
         (method (jget notify "method" ""))
         (args (let ((a (jget notify "args"))) (if (hash-table-p a) a (obj)))))
    (cond
      ((equal method "run_signal") (apply-run-signal ext args))
      ((equal method "invalidate")
       (let ((message (jget args "message")))
         (sb-thread:with-mutex ((extension-state-lock ext))
           (when (and (null (extension-stale-message ext)) (stringp message) (plusp (length message)))
             (setf (extension-stale-message ext) message)))))
      ((equal method "state_update")
       (let ((state (or (jget args "state") (obj))) footer-changed branch-changed callbacks)
         (sb-thread:with-mutex ((extension-state-lock ext))
           (multiple-value-setq (footer-changed branch-changed) (apply-footer-data ext (jget state "footerData")))
           (apply-ui-state ext state)
           (when (and footer-changed branch-changed)
             (setf callbacks (mapcar #'cdr (extension-branch-subscribers ext)))))
         (run-hooks '*state-hooks* ext state)
         (dolist (callback callbacks)
           (handler-case (funcall callback)
             (error (e) (ignore-errors (notify-host ext "ui.notify"
                                                    (obj "message" (format nil "footer branch subscriber failed: ~A" e)
                                                         "level" "error"))))))))
      ((equal method "width_change")
       (let ((w (jget args "width")))
         (when (and (integerp w) (plusp w))
           (sb-thread:with-mutex ((extension-state-lock ext)) (setf (extension-width ext) w))
           (dispatch-width-change ext w))))
      ((equal method "height_change")
       (let ((h (jget args "height"))) (when (and (integerp h) (plusp h)) (sb-thread:with-mutex ((extension-state-lock ext)) (setf (extension-height ext) h)))))
      (t (let ((handler (gethash method *notify-handlers*)))
           (when handler
             (handler-case (funcall handler ext args)
               (error (e) (format *error-output* "~A: notify ~A failed: ~A~%" (extension-name ext) method e)))))))))

;;; ---------------------------------------------------------------- event stream replicas

(defun clone-stream-value (value)
  (cond ((hash-table-p value)
         (let ((copy (make-hash-table :test 'equal)))
           (maphash (lambda (k v) (setf (gethash k copy) (clone-stream-value v))) value)
           copy))
        ((and (vectorp value) (not (stringp value))) (map 'simple-vector #'clone-stream-value value))
        (t value)))

(defun stream-member (parent key)
  (cond ((and (hash-table-p parent) (stringp key))
         (multiple-value-bind (v found) (gethash key parent)
           (if found v (error "event stream: bad path"))))
        ((and (simple-vector-p parent) (integerp key) (< -1 key (length parent))) (svref parent key))
        (t (error "event stream: bad path"))))

(defun stream-store (parent key value)
  "Store VALUE; the container that now holds the member (a grown vector replaces PARENT)."
  (cond ((and (hash-table-p parent) (stringp key)) (setf (gethash key parent) value) parent)
        ((and (simple-vector-p parent) (integerp key) (<= 0 key (length parent)))
         (if (= key (length parent))
             (concatenate 'simple-vector parent (vector value))
             (progn (setf (svref parent key) value) parent)))
        (t (error "event stream: bad path"))))

(defun stream-update (container path name value)
  "CONTAINER with the operation applied at PATH (a list); a vector that grew is a new object, so callers store the result."
  (if (null (cdr path))
      (let ((key (car path)))
        (cond ((equal name "append")
               (let ((current (stream-member container key)))
                 (unless (and (stringp current) (stringp value)) (error "event stream: append to a non-string"))
                 (stream-store container key (concatenate 'string current value))))
              ((equal name "set") (stream-store container key value))
              (t (error "event stream: unknown operation ~S" name))))
      (let* ((key (car path))
             (child (stream-member container key))
             (new-child (stream-update child (cdr path) name value)))
        (if (eq child new-child) container (stream-store container key new-child)))))

(defun apply-stream-ops (root ops)
  (unless (and (vectorp ops) (not (stringp ops))) (error "event stream: ops are not a list"))
  (loop for op across ops
        do (let ((path (jget op "path")) (value (jget op "value")) (name (jget op "op")))
             (unless (and (vectorp path) (not (stringp path))) (error "event stream: bad path"))
             (if (zerop (length path))
                 (progn (unless (equal name "set") (error "event stream: bad root operation"))
                        (setf root value))
                 (setf root (stream-update root (coerce path 'list) name value)))))
  root)

(defun apply-event-stream (ext req)
  "Replace the request's args with the full payload its stream member produces."
  (let ((stream (jget req "stream")))
    (when (hash-table-p stream)
      (let* ((name (jget req "event" "")) (key (let ((k (jget stream "key"))) (if (stringp k) k "")))
             (ident (cons name key))
             (replicas (extension-replicas ext)))
        (handler-case
            (let (root)
              (if (jget req "args")
                  (setf root (jget req "args"))
                  (let ((replica (gethash ident replicas))
                        (base (let ((b (jget stream "base"))) (if (integerp b) b 0))))
                    (unless (and replica (eql (car replica) base))
                      (error "~A delta applies to payload ~D, the replica holds a different one" name base))
                    (setf root (apply-stream-ops (cdr replica) (jget stream "ops")))))
              (setf (gethash ident replicas) (cons (let ((s (jget stream "seq"))) (if (integerp s) s 0)) root))
              (setf (gethash "args" req) (clone-stream-value root)))
          (error (e)
            (remhash ident replicas)
            (setf (gethash "_stream_error" req) (princ-to-string e))))
        (let ((evict (jget stream "evict")))
          (when (and (vectorp evict) (not (stringp evict)))
            (loop for evicted across evict do (remhash (cons name evicted) replicas))))))))

;;; ---------------------------------------------------------------- serving requests

(defun condition-message (condition)
  (handler-case (princ-to-string condition)
    (error () (format nil "~S" (type-of condition)))))

(defun wait-loaded (ext)
  (sb-thread:with-mutex ((extension-loaded-lock ext))
    (loop until (extension-loaded ext)
          do (sb-thread:condition-wait (extension-loaded-queue ext) (extension-loaded-lock ext)))))

(defun user-bash-event-result (value)
  "Preserve a present number-or-undefined exit code (null) across JSON, as the other SDKs do."
  (if (and (hash-table-p value) (hash-table-p (jget value "result")))
      (let* ((result (jget value "result"))
             (copy (make-hash-table :test 'equal))
             (undefined (and (nth-value 1 (gethash "exitCode" result)) (eq (jget result "exitCode") :null))))
        (maphash (lambda (k v)
                   (unless (or (and undefined (equal k "exitCode"))
                               (and (equal k "fullOutputPath") (eq v :null)))
                     (setf (gethash k copy) v)))
                 result)
        (let ((reply (make-hash-table :test 'equal)))
          (maphash (lambda (k v) (setf (gethash k reply) v)) value)
          (setf (gethash "result" reply) copy
                (gethash "_pigUserBashExitCodeUndefined" reply) (if undefined t :false))
          reply))
      value))

(declaim (ftype function user-bash-operations-reply tool-start-begin tool-start-respond tool-start-end tool-start-release tool-batches-reserve))

(defun messages-encoding (messages)
  (handler-case (to-json messages) (error () nil)))

(defun run-event-handler (ext ctx req)
  "The reply (values result error-message) of the event request REQ."
  (declare (ignorable ext))
  (let* ((handler-id (let ((h (jget req "handler_id"))) (if (integerp h) h 0)))
         (handler (gethash handler-id (extension-event-handlers ext)))
         (event (jget req "event" "")))
    (when (jget req "_stream_error") (error "~A" (jget req "_stream_error")))
    (unless handler (error "unknown event handler ~D for ~A" handler-id event))
    (let ((data (let ((d (jget req "args"))) (if (hash-table-p d) d (or d (obj))))))
      (cond
        ((member event '("agent_before_settle" "turn_end") :test #'equal)
         (let (result error-message)
           (handler-case
               (progn (ticket-begin (request-ticket (ctx-request ctx)))
                      (setf result (funcall handler ctx data)))
             (serious-condition (c) (setf error-message (condition-message c))))
           ;; the handler appends to the event's entries: the reply carries the list it left
           (values (obj "_pigBoundaryEntries" (or (jget data "entries") (vector)) "_pigBoundaryResult" result) error-message)))
        ((equal event "tool_call")
         (let* ((input (jget data "input")) (before (to-json input)) result error-message)
           (handler-case
               (progn (ticket-begin (request-ticket (ctx-request ctx)))
                      (setf result (funcall handler ctx data)))
             (serious-condition (c) (setf error-message (condition-message c))))
           (let ((reply (obj "_pigToolCallResult" result)))
             (unless (equal (to-json input) before) (setf (gethash "_pigToolCallInput" reply) input))
             (values reply error-message))))
        ((equal event "before_agent_start")
         (let ((options (jget data "systemPromptOptions")) result error-message)
           (unless (hash-table-p options) (error "before_agent_start carries no systemPromptOptions"))
           (flet ((default (key value) (unless (nth-value 1 (gethash key options)) (setf (gethash key options) value))))
             (default "selectedTools" (vector)) (default "hiddenTools" (vector))
             (default "toolSnippets" (obj)) (default "toolGuidelines" (obj))
             (default "promptGuidelines" (vector)) (default "contextFiles" (vector)) (default "skills" (vector)))
           (let ((sp (make-system-prompt ctx options (let ((p (jget data "systemPrompt"))) (if (stringp p) p "")))))
             (setf (system-prompt-key sp) (to-json options))
             (setf (ctx-system-prompt ctx) sp)
             ;; Pi's event.systemPrompt is a getter over the shared options: reading it through jget renders them now
             (when (nth-value 1 (gethash "systemPrompt" data))
               (setf (gethash "systemPrompt" data) (make-lazy-value (lambda () (system-prompt-get ctx))))))
           (handler-case
               (progn (ticket-begin (request-ticket (ctx-request ctx)))
                      (setf result (funcall handler ctx data)))
             (serious-condition (c) (setf error-message (condition-message c))))
           (values (obj "_pigPromptSections" (jget options "sections")
                        "_pigPromptSelectedTools" (jget options "selectedTools")
                        "_pigPromptOptions" options
                        "_pigPromptResult" result)
                   error-message)))
        (t
         (let* ((messages (jget data "messages"))
                (context-event (member event '("context" "context_with_system") :test #'equal))
                (snapshot (and context-event (vectorp messages) (not (stringp messages)) (coerce messages 'list)))
                (encoded-before (and snapshot (messages-encoding messages))))
           (ticket-begin (request-ticket (ctx-request ctx)))
           (let ((result (funcall handler ctx data)))
             (when (equal event "user_bash")
               (setf result (or (user-bash-operations-reply result) (user-bash-event-result result))))
             (when (and context-event snapshot)
               (let* ((returned (let ((r (and (hash-table-p result) (jget result "messages")))) (or r messages)))
                      (unchanged (and (vectorp returned) (= (length returned) (length snapshot))
                                      (every #'eq (coerce returned 'list) snapshot))))
                 (setf result
                       (if (and unchanged encoded-before (equal (messages-encoding returned) encoded-before))
                           (obj "_pigContextUnchanged" t)
                           (obj "messages" returned "_pigContextUnchanged" (if unchanged t :false))))))
             (values result nil))))))))

(defvar *child-tool-handler* nil
  "(lambda (ext session-id name)) -> the handler of a custom tool of a child session (child-session.lisp), or NIL.")

(defun handle-request (ext env ctx)
  (let* ((id (jget env "id" "")) (req (or (jget env "request") (obj)))
         (method (jget req "method")) (request (ctx-request ctx)))
    (handler-case
        (cond
          ((equal method "tool_call")
           (let* ((name (jget req "tool" "")) (params (let ((a (jget req "args"))) (if (hash-table-p a) a (obj))))
                  (child (let ((c (jget req "child_session"))) (and (stringp c) (plusp (length c)) c)))
                  (handler (if child
                               (and *child-tool-handler* (funcall *child-tool-handler* ext child name))
                               (gethash name (extension-tool-handlers ext)))))
             (unless handler (error "unknown tool ~S" name))
             (ticket-begin (request-ticket request))
             (when (ctx-tool-start ctx) (tool-start-begin (ctx-tool-start ctx)))
             ;; a handler whose dialog was answered before another's responds after it, as Pi's continuations run in the order of the answers
             (let ((payload (normalize-tool-result (funcall handler ctx params))))
               (tool-start-respond (ctx-tool-start ctx) (lambda () (respond ext id payload nil))))))
          ((equal method "command")
           (let* ((name (jget req "tool" "")) (args (jget req "args" ""))
                  (handler (gethash name (extension-command-handlers ext))))
             (unless handler (error "unknown command ~S" name))
             (ticket-begin (request-ticket request))
             (funcall handler ctx (if (stringp args) args (to-json args)))
             (respond ext id nil nil)))
          ((equal method "shortcut")
           (let ((handler (gethash (jget req "tool" "") (extension-shortcut-handlers ext))))
             (unless handler (error "unknown shortcut ~S" (jget req "tool" "")))
             (funcall handler ctx)
             (respond ext id nil nil)))
          ((equal method "event")
           (multiple-value-bind (result error-message) (run-event-handler ext ctx req)
             (respond ext id result error-message)))
          ((gethash method *request-handlers*)
           (ticket-begin (request-ticket request))
           (respond ext id (funcall (gethash method *request-handlers*) ext ctx req) nil))
          (t (respond ext id nil (format nil "unknown method: ~A" method))))
      (serious-condition (c)
        (handler-case (tool-start-respond (ctx-tool-start ctx) (lambda () (respond ext id nil (condition-message c))))
          (error () nil))))
    (when request (ticket-begin (request-ticket request)))
    (tool-start-end (ctx-tool-start ctx))))

(defun handle-request-thread (ext env ctx)
  (unwind-protect
       (progn
         ;; A tui.alt.cb request answers a screen the extension created, which can be an on-loaded handler's: it must not wait for that handler to return.
         (unless (equal (jget (jget env "request") "method") "tui.alt.cb") (wait-loaded ext))
         (handle-request ext env ctx))
    (sb-thread:with-mutex ((extension-state-lock ext))
      (setf (extension-request-threads ext) (remove sb-thread:*current-thread* (extension-request-threads ext))))))

(defun start-request (ext env)
  (let* ((id (jget env "id" "")) (req (or (jget env "request") (obj)))
         (request (make-request id (make-abort-signal))))
    (sb-thread:with-mutex ((extension-state-lock ext))
      (setf (gethash id (extension-active ext)) request))
    (let ((ctx (make-ctx ext request env)))
      (let ((batch (jget req "batch")))
        ;; only the calls of one parallel batch take part in the dialog and continuation orders
        (when (and (equal (jget req "method") "tool_call") (stringp batch) (plusp (length batch)))
          (setf (ctx-tool-start ctx) (tool-batches-reserve ext batch))))
      (when (starts-in-arrival-order-p (jget req "method"))
        (setf (request-ticket request) (reserve-ticket ext)))
      (send-request-state ext id "started")
      (handler-case
          (let ((thread (sb-thread:make-thread #'handle-request-thread :name (format nil "pig-request-~A" id)
                                                                       :arguments (list ext env ctx))))
            (sb-thread:with-mutex ((extension-state-lock ext))
              (push thread (extension-request-threads ext))))
        (error (e)
          (when (request-ticket request) (latch-set (start-ticket-done (request-ticket request))))
          (when (ctx-tool-start ctx) (tool-start-release (ctx-tool-start ctx)))
          (respond ext id nil (format nil "start extension handler: ~A" e)))))))

(defun handle-cancel (ext env)
  (let* ((cancel (or (jget env "cancel") (obj)))
         (id (let ((r (jget cancel "request_id"))) (if (stringp r) r (jget env "id" ""))))
         (reason (let ((r (jget cancel "reason"))) (and (stringp r) r)))
         (request nil) (cancelled '()))
    (sb-thread:with-mutex ((extension-state-lock ext))
      (setf request (gethash id (extension-active ext)))
      (when request
        (setf (request-reason request) reason)
        (unless (request-finished request) (setf (request-state request) :cancelled)))
      (maphash (lambda (call-id slot) (declare (ignore call-id))
                 (when (equal (call-slot-parent-id slot) id) (push slot cancelled)))
               (extension-pending ext)))
    (when request (signal-abort (request-signal request) reason))
    (dolist (slot cancelled) (finish-slot slot nil :cancelled t))))

(defun stop-runtime (ext)
  "End every pending call and request; wait up to two seconds for handler threads. True when they all stopped."
  (let (pending signals threads)
    (run-hooks '*stop-hooks* ext)
    (sb-thread:with-mutex ((extension-state-lock ext))
      (setf (extension-shutdown ext) t)
      (maphash (lambda (k v) (declare (ignore k)) (push v pending)) (extension-pending ext))
      (maphash (lambda (k v) (declare (ignore k)) (push (request-signal v) signals)) (extension-active ext))
      (setf threads (remove sb-thread:*current-thread* (copy-list (extension-request-threads ext)))))
    (dolist (slot pending) (finish-slot slot nil))
    (dolist (signal signals) (signal-abort signal))
    (let ((deadline (+ (get-internal-real-time) (* 2 internal-time-units-per-second))))
      (dolist (thread threads)
        (let ((remaining (/ (- deadline (get-internal-real-time)) internal-time-units-per-second)))
          (sb-thread:join-thread thread :default nil :timeout (max 0.0 remaining))))
      (notany #'sb-thread:thread-alive-p threads))))

(defun run-loaded-handlers (ext)
  (let ((handlers (extension-loaded-handlers ext)))
    (setf (extension-loaded-handlers ext) '())
    (when handlers
      (setf (extension-loaded ext) nil)
      (let ((thread
              (sb-thread:make-thread
               (lambda ()
                 (unwind-protect
                      (dolist (handler handlers)
                        (handler-case (funcall handler (make-ctx ext))
                          (serious-condition (c)
                            (format *error-output* "pig: on-loaded handler failed: ~A~%" (condition-message c)))))
                   (sb-thread:with-mutex ((extension-loaded-lock ext))
                     (setf (extension-loaded ext) t)
                     (sb-thread:condition-broadcast (extension-loaded-queue ext)))
                   (sb-thread:with-mutex ((extension-state-lock ext))
                     (setf (extension-request-threads ext) (remove sb-thread:*current-thread* (extension-request-threads ext))))))
               :name "pig-on-loaded")))
        (sb-thread:with-mutex ((extension-state-lock ext))
          (push thread (extension-request-threads ext)))))))

(defun read-ready (ext conn)
  "Read frames until the host's ready and return it, and as a second value the events.dispatch requests that came first, in arrival order: a listener the host
dispatches to while the extension registers is served once the extension is ready, as the other SDKs and the node runtime serve it.
The first value is :SHUTDOWN when the host shut the extension down first, whether the frame was read here or by a call the extension made before it registered."
  (when (helper-take-shutdown conn) (return-from read-ready (values :shutdown (reverse (shiftf (extension-early-dispatches ext) '())))))
  (let ((early (shiftf (extension-early-dispatches ext) '())))
    (loop
      (let ((env (read-frame conn)))
        (when (eq env :eof) (error "the host closed the connection before it answered the registration"))
        (let ((type (jget env "type")))
          (cond ((equal type "ready") (return (values env (nreverse early))))
                ((equal type "shutdown") (return (values :shutdown (nreverse early))))
                ((refused-request-p env) (refuse-request conn env))
                ((equal type "refused") (note-dropped-frame))
                ((equal type "ping")
                 (send-frame conn (obj "type" "pong" "pong" (obj "nonce" (jget (or (jget env "ping") (obj)) "nonce" "")))))
                ((and (equal type "request") (equal (jget (or (jget env "request") (obj)) "method") "events.dispatch"))
                 (push env early))
                (t nil)))))))

(declaim (ftype function helper-take-shutdown))

(defun serve (ext conn)
  "Register EXT over CONN and serve the host until it shuts the extension down or closes the connection.
True when every handler thread stopped in time.
A shutdown before ready ends the run as one after ready does: no error, because Pi's session shutdown never fails an extension (runner.ts emitSessionShutdownEvent) and the node runtime returns.
The register frame is sent, and the dispatches read before the shutdown are answered while the handler threads stop."
  (setf (extension-conn ext) conn)
  (let ((stopped t) (early '()) (shutdown nil))
    (unwind-protect
         (progn
           (let ((ready nil))
             (sb-thread:with-mutex ((extension-reg-lock ext))
               (send-frame conn (obj "type" "register" "register" (register-payload ext)))
               (multiple-value-setq (ready early) (read-ready ext conn))
               (setf (extension-live ext) t))
             (setf shutdown (eq ready :shutdown))
             (unless shutdown
               (let ((data (or (jget ready "ready") (obj))))
                 (sb-thread:with-mutex ((extension-state-lock ext))
                   (setf (extension-cwd ext) (let ((c (jget data "cwd"))) (if (stringp c) c ""))
                         (extension-mode ext) (let ((m (jget data "mode"))) (if (stringp m) m ""))
                         (extension-width ext) (let ((w (jget data "width"))) (if (integerp w) w 0))
                         (extension-height ext) (let ((h (jget data "height"))) (if (integerp h) h 0)))
                   (let ((state (or (jget data "state") (obj))))
                     (apply-footer-data ext (jget state "footerData"))
                     (apply-ui-state ext state)))
                 (run-hooks '*ready-hooks* ext data))))
           (unless shutdown (run-loaded-handlers ext))
           (dolist (env early) (start-request ext env))
           (unless shutdown
             (loop
               (let ((env (handler-case (read-frame conn) (error () :eof))))
                 (when (eq env :eof) (return))
                 (let ((type (jget env "type")))
                   (cond
                     ((equal type "ping")
                      (send-frame conn (obj "type" "pong" "pong" (obj "nonce" (jget (or (jget env "ping") (obj)) "nonce" "")))))
                     ((equal type "call_result") (deliver-call-result ext env))
                     ((equal type "notify") (handle-notify ext env))
                     ((refused-request-p env)
                      (respond ext (jget env "id" "") nil (jget env "refused")))
                     ((equal type "refused") (note-dropped-frame))
                     ((equal type "request")
                      (apply-event-stream ext (or (jget env "request") (obj)))
                      (start-request ext env))
                     ((equal type "cancel") (handle-cancel ext env))
                     ((equal type "shutdown") (return))))))))
      (setf stopped (stop-runtime ext))
      (remhash ext *ticket-tails*)
      (conn-close conn))
    stopped))
